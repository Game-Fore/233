﻿#include <iostream>
using namespace std;
class Solution {
    int otvet(int n) {
        long long result = 0;
        long long place = 1; // текущий разряд

        while (place <= n) {
            long long right = n % place;
            int digit = (n / place) % 10;
            long long left = n / (place * 10);

            if (digit == 0) {
                result += left * place;
            }

            else if (digit == 1) {
                result += left * place;
                result += right + 1;
            }

            else {
                result += (left + 1) * place;
            }

            place *= 10;
        }
        return result;
    }

    int main() {
        int n;
        cin >> n;
        cout << otvet(n);
        return 0;
    }
};

